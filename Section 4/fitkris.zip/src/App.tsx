/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Activity, 
  Utensils, 
  Flame, 
  PieChart, 
  Plus, 
  ChevronRight, 
  CheckCircle2, 
  ArrowRight,
  Menu,
  X,
  Target,
  Zap,
  ShieldCheck,
  ChefHat,
  Trash2,
  Send,
  Loader2,
  Brain
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const Nav = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-zinc-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
              <Activity className="text-white w-5 h-5" />
            </div>
            <span className="text-xl font-bold tracking-tight text-zinc-900">Fitkris</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm font-medium text-zinc-600 hover:text-emerald-600 transition-colors">Features</a>
            <a href="#best-recipes" className="text-sm font-medium text-zinc-600 hover:text-emerald-600 transition-colors">Best Recipes</a>
            <a href="#how-it-works" className="text-sm font-medium text-zinc-600 hover:text-emerald-600 transition-colors">How it Works</a>
            <a href="#contact" className="text-sm font-medium text-zinc-600 hover:text-emerald-600 transition-colors">Contact</a>
            <button className="bg-zinc-900 text-white px-5 py-2 rounded-full text-sm font-medium hover:bg-zinc-800 transition-all">
              Get Started
            </button>
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-zinc-600">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden bg-white border-b border-zinc-100 px-4 py-6 flex flex-col gap-4"
          >
            <a href="#features" className="text-lg font-medium text-zinc-900">Features</a>
            <a href="#best-recipes" className="text-lg font-medium text-zinc-900">Best Recipes</a>
            <a href="#how-it-works" className="text-lg font-medium text-zinc-900">How it Works</a>
            <a href="#contact" className="text-lg font-medium text-zinc-900">Contact</a>
            <button className="bg-emerald-500 text-white py-3 rounded-xl font-bold">Get Started</button>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const FeatureCard = ({ icon: Icon, title, description, delay }: { icon: any, title: string, description: string, delay: number }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ delay }}
    className="p-8 bg-white rounded-3xl border border-zinc-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
  >
    <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center mb-6">
      <Icon className="text-emerald-600 w-6 h-6" />
    </div>
    <h3 className="text-xl font-bold text-zinc-900 mb-3">{title}</h3>
    <p className="text-zinc-500 leading-relaxed">{description}</p>
  </motion.div>
);

const MacroBadge = ({ label, value, color }: { label: string, value: string, color: string }) => (
  <div className="flex flex-col items-center">
    <div className={`w-16 h-16 rounded-full border-4 ${color} flex items-center justify-center mb-2`}>
      <span className="text-xs font-bold">{value}</span>
    </div>
    <span className="text-[10px] uppercase tracking-wider font-semibold text-zinc-400">{label}</span>
  </div>
);

const AddDishSection = () => {
  const [dishName, setDishName] = useState('');
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [currentIngredient, setCurrentIngredient] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ kcal: number, p: string, c: string, f: string } | null>(null);

  const addIngredient = () => {
    if (currentIngredient.trim()) {
      setIngredients([...ingredients, currentIngredient.trim()]);
      setCurrentIngredient('');
    }
  };

  const calculateNutrition = async () => {
    if (ingredients.length === 0) return;
    setLoading(true);
    setResult(null);

    try {
      const prompt = `Analyze the following ingredients for a dish named "${dishName || 'Custom Dish'}" and provide the total calories (kcal), protein (g), carbohydrates (g), and fats (g). 
      Ingredients: ${ingredients.join(', ')}. 
      Return ONLY a JSON object with keys: kcal (number), p (string with 'g'), c (string with 'g'), f (string with 'g').`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: { responseMimeType: "application/json" }
      });

      const data = JSON.parse(response.text || '{}');
      setResult(data);
    } catch (error) {
      console.error("Nutrition calculation failed:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="add-dish" className="py-24 bg-zinc-900 text-white">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-5xl font-black mb-4">Create Your Custom Dish</h2>
          <p className="text-zinc-400">Add your favorite ingredients and let Fitkris calculate the perfect balance.</p>
        </div>

        <div className="bg-zinc-800 p-8 rounded-[32px] border border-zinc-700 shadow-2xl">
          <div className="mb-8">
            <label className="block text-sm font-bold text-zinc-400 uppercase tracking-wider mb-2">Dish Name</label>
            <input 
              type="text" 
              placeholder="e.g., Morning Power Bowl" 
              value={dishName}
              onChange={(e) => setDishName(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-700 rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 transition-colors"
            />
          </div>

          <div className="mb-8">
            <label className="block text-sm font-bold text-zinc-400 uppercase tracking-wider mb-2">Add Ingredients</label>
            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="e.g., 200g Chicken Breast" 
                value={currentIngredient}
                onChange={(e) => setCurrentIngredient(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addIngredient()}
                className="flex-1 bg-zinc-900 border border-zinc-700 rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 transition-colors"
              />
              <button 
                onClick={addIngredient}
                className="bg-emerald-500 hover:bg-emerald-600 text-white p-3 rounded-xl transition-colors"
              >
                <Plus className="w-6 h-6" />
              </button>
            </div>
          </div>

          <div className="space-y-3 mb-8">
            {ingredients.map((ing, idx) => (
              <motion.div 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                key={idx} 
                className="flex items-center justify-between bg-zinc-900/50 p-4 rounded-xl border border-zinc-700/50"
              >
                <span className="font-medium">{ing}</span>
                <button 
                  onClick={() => setIngredients(ingredients.filter((_, i) => i !== idx))}
                  className="text-zinc-500 hover:text-red-400 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </motion.div>
            ))}
            {ingredients.length === 0 && (
              <div className="text-center py-8 border-2 border-dashed border-zinc-700 rounded-2xl text-zinc-500 italic">
                No ingredients added yet
              </div>
            )}
          </div>

          {result && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mb-8 p-6 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl grid grid-cols-4 gap-4"
            >
              <div className="text-center">
                <div className="text-emerald-400 font-black text-xl">{result.kcal}</div>
                <div className="text-[10px] uppercase text-zinc-500 font-bold">Calories</div>
              </div>
              <div className="text-center">
                <div className="text-emerald-400 font-black text-xl">{result.p}</div>
                <div className="text-[10px] uppercase text-zinc-500 font-bold">Protein</div>
              </div>
              <div className="text-center">
                <div className="text-emerald-400 font-black text-xl">{result.c}</div>
                <div className="text-[10px] uppercase text-zinc-500 font-bold">Carbs</div>
              </div>
              <div className="text-center">
                <div className="text-emerald-400 font-black text-xl">{result.f}</div>
                <div className="text-[10px] uppercase text-zinc-500 font-bold">Fats</div>
              </div>
            </motion.div>
          )}

          <button 
            onClick={calculateNutrition}
            disabled={loading || ingredients.length === 0}
            className="w-full bg-emerald-500 hover:bg-emerald-600 disabled:bg-zinc-700 disabled:cursor-not-allowed text-white py-4 rounded-2xl font-bold text-lg transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Analyzing with AI...
              </>
            ) : (
              <>
                <Brain className="w-5 h-5" />
                Calculate Nutrition
              </>
            )}
          </button>
        </div>
      </div>
    </section>
  );
};

const BestRecipesSection = () => {
  const recipes = [
    { name: "Grilled Salmon with Asparagus", kcal: 450, p: "42g", c: "8g", f: "28g", img: "salmon-dish" },
    { name: "Quinoa Salad with Chickpeas", kcal: 380, p: "14g", c: "56g", f: "12g", img: "quinoa-salad" },
    { name: "Chicken Breast with Sweet Potato", kcal: 520, p: "48g", c: "45g", f: "10g", img: "grilled-chicken" },
    { name: "Avocado Toast with Poached Egg", kcal: 320, p: "12g", c: "24g", f: "22g", img: "avocado-toast" },
    { name: "Beef Stir-fry with Broccoli", kcal: 480, p: "38g", c: "15g", f: "30g", img: "beef-stir-fry" },
    { name: "Greek Yogurt with Berries", kcal: 250, p: "20g", c: "30g", f: "5g", img: "yogurt-bowl" },
    { name: "Lentil Soup with Spinach", kcal: 310, p: "18g", c: "48g", f: "4g", img: "lentil-soup" },
    { name: "Turkey Tacos (Whole Wheat)", kcal: 410, p: "32g", c: "35g", f: "16g", img: "tacos-food" },
    { name: "Baked Tofu with Brown Rice", kcal: 440, p: "24g", c: "62g", f: "12g", img: "tofu-dish" },
    { name: "Protein Pancakes with Banana", kcal: 390, p: "30g", c: "45g", f: "8g", img: "pancakes-food" },
  ];

  return (
    <section id="best-recipes" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 text-amber-700 text-xs font-bold mb-4">
            <ChefHat className="w-3 h-3" />
            <span>CURATED BY NUTRITIONISTS</span>
          </div>
          <h2 className="text-3xl lg:text-5xl font-black mb-4">Our Best Recipes</h2>
          <p className="text-zinc-500 max-w-2xl mx-auto">Discover our top-rated, macro-balanced meals designed to keep you fueled and satisfied.</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {recipes.map((recipe, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.05 }}
              className="group bg-zinc-50 rounded-3xl overflow-hidden border border-zinc-100 hover:shadow-xl transition-all duration-300"
            >
              <div className="aspect-square overflow-hidden relative">
                <img 
                  src={`https://loremflickr.com/400/400/${recipe.img},food`} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                  alt={recipe.name}
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded-lg text-[10px] font-bold text-zinc-900">
                  {recipe.kcal} kcal
                </div>
              </div>
              <div className="p-4">
                <h4 className="font-bold text-sm mb-3 line-clamp-1">{recipe.name}</h4>
                <div className="flex justify-between text-[10px] font-bold uppercase tracking-tighter">
                  <span className="text-emerald-600">P: {recipe.p}</span>
                  <span className="text-blue-600">C: {recipe.c}</span>
                  <span className="text-amber-600">F: {recipe.f}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const ContactForm = () => {
  return (
    <section id="contact" className="py-24 bg-zinc-50">
      <div className="max-w-xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-black mb-4">Get in Touch</h2>
          <p className="text-zinc-500">Have questions? We're here to help you on your fitness journey.</p>
        </div>
        
        <form className="space-y-6 bg-white p-8 rounded-[32px] shadow-xl border border-zinc-100">
          <div>
            <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2">Full Name</label>
            <input 
              type="text" 
              placeholder="[ Enter your name ]" 
              className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2">Email Address</label>
            <input 
              type="email" 
              placeholder="[ Enter your email ]" 
              className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2">Your Message</label>
            <textarea 
              rows={4}
              placeholder="[ How can we help you? ]" 
              className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all resize-none"
            ></textarea>
          </div>
          <button className="w-full bg-zinc-900 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-zinc-800 transition-all">
            Send Message
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </section>
  );
};

export default function App() {
  return (
    <div className="min-h-screen bg-zinc-50 font-sans text-zinc-900">
      <Nav />

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs font-bold mb-6">
              <Zap className="w-3 h-3" />
              <span>NEW: AI RECIPE ANALYZER</span>
            </div>
            <h1 className="text-5xl lg:text-7xl font-black tracking-tight leading-[1.1] mb-6">
              Master Your <span className="text-emerald-500">Macros</span>, Fuel Your Life.
            </h1>
            <p className="text-lg text-zinc-600 mb-10 max-w-lg leading-relaxed">
              Fitkris is the ultimate nutrition companion. Add recipes in seconds, track calories with precision, and hit your fitness goals faster than ever.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-emerald-500 text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-emerald-600 transition-all shadow-lg shadow-emerald-200 flex items-center justify-center gap-2 group">
                Start Free Trial
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
            <div className="mt-10 flex items-center gap-4">
              <div className="flex -space-x-3">
                {[1, 2, 3, 4].map((i) => (
                  <img 
                    key={i}
                    src={`https://picsum.photos/seed/user${i}/100/100`} 
                    className="w-10 h-10 rounded-full border-2 border-white" 
                    alt="User"
                    referrerPolicy="no-referrer"
                  />
                ))}
              </div>
              <p className="text-sm text-zinc-500">
                Joined by <span className="font-bold text-zinc-900">10,000+</span> fitness enthusiasts
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="bg-zinc-900 rounded-[40px] p-8 shadow-2xl relative z-10 overflow-hidden">
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-white font-bold">Today's Nutrition</h3>
                <div className="text-emerald-400 text-sm font-mono">1,840 / 2,200 kcal</div>
              </div>
              
              <div className="grid grid-cols-3 gap-4 mb-8">
                <MacroBadge label="Protein" value="145g" color="border-emerald-500 text-emerald-500" />
                <MacroBadge label="Carbs" value="210g" color="border-blue-500 text-blue-500" />
                <MacroBadge label="Fats" value="65g" color="border-amber-500 text-amber-500" />
              </div>

              <div className="space-y-4">
                <div className="bg-zinc-800/50 p-4 rounded-2xl flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-emerald-500/20 rounded-xl flex items-center justify-center">
                      <Utensils className="text-emerald-400 w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-white text-sm font-bold">Grilled Salmon Bowl</div>
                      <div className="text-zinc-500 text-xs">Lunch • 540 kcal</div>
                    </div>
                  </div>
                  <CheckCircle2 className="text-emerald-500 w-5 h-5" />
                </div>
                <div className="bg-zinc-800/50 p-4 rounded-2xl flex items-center justify-between opacity-50">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-zinc-700 rounded-xl flex items-center justify-center">
                      <Plus className="text-zinc-400 w-5 h-5" />
                    </div>
                    <div className="text-zinc-400 text-sm font-bold">Add Dinner</div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -top-10 -right-10 w-64 h-64 bg-emerald-500/10 blur-3xl rounded-full z-0" />
            <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-blue-500/10 blur-3xl rounded-full z-0" />
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-black mb-4">Everything You Need to Succeed</h2>
            <p className="text-zinc-500 max-w-2xl mx-auto">We've built the most powerful tools for your nutrition journey, designed to be simple yet incredibly effective.</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard 
              icon={Zap}
              title="AI Recipe Analyzer"
              description="Paste any recipe URL or upload a photo of a menu. Our AI instantly breaks down ingredients and calculates full nutritional data."
              delay={0.1}
            />
            <FeatureCard 
              icon={Target}
              title="Personalized Macro Goals"
              description="Set targets based on your specific goals—whether it's muscle gain, fat loss, or maintenance. We adjust as you progress."
              delay={0.2}
            />
            <FeatureCard 
              icon={PieChart}
              title="Visual Progress Tracking"
              description="Beautiful, easy-to-read charts that show your daily, weekly, and monthly trends. See exactly where your calories are coming from."
              delay={0.3}
            />
            <FeatureCard 
              icon={Utensils}
              title="Smart Meal Planner"
              description="Generate weekly meal plans that fit your macro targets perfectly. Includes automated grocery lists to save you time."
              delay={0.4}
            />
            <FeatureCard 
              icon={ShieldCheck}
              title="Verified Food Database"
              description="Access over 2 million verified food items. No more guessing—get accurate data for every single ingredient."
              delay={0.5}
            />
            <FeatureCard 
              icon={Activity}
              title="Fitness Integration"
              description="Sync with Apple Health, Google Fit, and Strava to automatically adjust your calorie needs based on your daily activity."
              delay={0.6}
            />
          </div>
        </div>
      </section>

      <AddDishSection />

      {/* How it Works */}
      <section id="how-it-works" className="py-24 bg-zinc-50 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-20 items-center">
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&q=80&w=800" 
                className="rounded-[40px] shadow-2xl relative z-10 aspect-[4/5] object-cover" 
                alt="Modern Kitchen"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-3xl shadow-xl z-20 max-w-[240px]">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
                    <Flame className="text-white w-4 h-4" />
                  </div>
                  <span className="font-bold text-sm">Calorie Burned</span>
                </div>
                <div className="text-2xl font-black">420 kcal</div>
                <div className="text-xs text-zinc-400 mt-1">Morning Workout • 45 min</div>
              </div>
            </div>
            
            <div>
              <h2 className="text-4xl font-black mb-8">From Recipe to Result in 3 Simple Steps</h2>
              <div className="space-y-12">
                <div className="flex gap-6">
                  <div className="flex-shrink-0 w-12 h-12 bg-zinc-900 text-white rounded-2xl flex items-center justify-center font-bold text-xl">1</div>
                  <div>
                    <h4 className="text-xl font-bold mb-2">Add Your Recipe</h4>
                    <p className="text-zinc-500">Scan a cookbook, paste a link, or type it in. Our system handles the heavy lifting of ingredient parsing.</p>
                  </div>
                </div>
                <div className="flex gap-6">
                  <div className="flex-shrink-0 w-12 h-12 bg-zinc-900 text-white rounded-2xl flex items-center justify-center font-bold text-xl">2</div>
                  <div>
                    <h4 className="text-xl font-bold mb-2">Get Instant Macros</h4>
                    <p className="text-zinc-500">Instantly see the protein, carbs, fats, and calories. Adjust portions to see how it affects your daily totals.</p>
                  </div>
                </div>
                <div className="flex gap-6">
                  <div className="flex-shrink-0 w-12 h-12 bg-zinc-900 text-white rounded-2xl flex items-center justify-center font-bold text-xl">3</div>
                  <div>
                    <h4 className="text-xl font-bold mb-2">Track & Transform</h4>
                    <p className="text-zinc-500">Log your meals and watch your progress. Our adaptive algorithms help you stay on track for your goals.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <BestRecipesSection />

      {/* CTA Section */}
      <section className="py-24 bg-emerald-500">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl lg:text-6xl font-black text-white mb-8">Ready to transform your nutrition?</h2>
          <p className="text-emerald-50 text-xl mb-12">Join thousands of others who are reaching their goals with Fitkris. Start your 14-day free trial today.</p>
          <button className="bg-white text-emerald-600 px-10 py-5 rounded-2xl font-black text-xl hover:bg-emerald-50 transition-all shadow-xl">
            Get Fitkris Now
          </button>
          <p className="text-emerald-100 mt-6 text-sm">No credit card required. Cancel anytime.</p>
        </div>
      </section>

      <ContactForm />

      {/* Footer */}
      <footer className="bg-white py-12 border-t border-zinc-100">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
              <Activity className="text-white w-5 h-5" />
            </div>
            <span className="text-xl font-bold tracking-tight text-zinc-900">Fitkris</span>
          </div>
          
          <div className="flex gap-8 text-sm font-medium text-zinc-500">
            <a href="#" className="hover:text-emerald-600">Privacy</a>
            <a href="#" className="hover:text-emerald-600">Terms</a>
            <a href="#" className="hover:text-emerald-600">Contact</a>
            <a href="#" className="hover:text-emerald-600">Twitter</a>
          </div>
          
          <p className="text-sm text-zinc-400">© 2026 Fitkris. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
