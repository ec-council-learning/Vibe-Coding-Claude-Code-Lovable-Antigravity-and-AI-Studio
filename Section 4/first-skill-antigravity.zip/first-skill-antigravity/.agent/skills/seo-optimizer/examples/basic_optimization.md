# Example: Basic SEO Optimization

## Before Optimization
**Target Keyword**: "Best Coffee for Home"

### Title tag (Inside `<head>`):
`<title>Coffee at home</title>`

### Meta Description:
`<meta name="description" content="We sell some cool coffee you can have at home and drink while you work or something. It's really good and you will like it. Buy now.">`

### Header:
`<h1>My favorite coffee brands</h1>`

### Content:
"Are you looking for a good way to start your day? Many people like to have a hot cup of joe in the morning. We offer a wide variety of beans and grounds that you can use with your favorite brewer. It's really convenient and tastes great."

---

## After Optimization
**Target Keyword**: "Best Coffee for Home"

### Title tag (Inside `<head>`):
`<title>Best Coffee for Home: Top Picks for Brewing the Perfect Cup</title>`
*Why: Placed keyword at the beginning, included emotional hooks, and kept it under 60 characters.*

### Meta Description:
`<meta name="description" content="Discover the best coffee for home brewing. From rich espresso roasts to smooth medium blends, find the perfect beans to elevate your morning routine today!">`
*Why: Includes the primary keyword, provides a clear benefit, and falls within the 150-160 character range.*

### Header:
`<h1>The Ultimate Guide to the Best Coffee for Home Brewing</h1>`
*Why: Incorporates the keyword into an H1 that sounds like a comprehensive guide.*

### Content:
"Searching for the **best coffee for home** shouldn't be a chore. Whether you prefer a bold French press brew or a delicate pour-over, choosing high-quality beans is essential for the perfect flavor profile. 

At [Brand Name], we source only the finest specialty beans to ensure your morning ritual is nothing short of extraordinary. Explore our selection of artisanal roasts and ground coffee options, all delivered fresh to your door."

*Why: Keyword is bolded in the first paragraph, paragraphs are short and easy to read, and it includes a clear intent to help the user.*
