---
name: SEO Optimizer
description: Optimizes a website for search engines. The role of that skill is also to optimize any type of the text given to the agent with a clear request to optimize it in terms of SEO.
---

# SEO Optimizer Skill

This skill provides the AI agent with a robust framework for performing search engine optimization (SEO) on websites and content. It covers everything from initial content analysis to technical SEO recommendations.

## Core Objectives
1.  **Organic Visibility**: Enhance the content's placement on Search Engine Results Pages (SERPs) to drive consistent traffic.
2.  **Intent Alignment**: Precisely match the content's messaging with the specific goals and queries of the target audience.
3.  **Engagement & UX**: Deliver a seamless, accessible, and high-quality reading experience that satisfies both users and search bots.
4.  **Content Authority**: Establish the page as a reliable and trustworthy resource within its industry or niche.
5.  **Conversion Performance**: Optimize meta-elements and CTAs to maximize click-through rates and user-driven outcomes.

## Optimization Workflow

### 1. Analysis and Keyword Research
- Identify the primary keyword and secondary (LSI) keywords.
- Analyze the intent of the search (informational, transactional, navigational).
- Check existing content for keyword density (aim for 1-2%).

### 2. On-Page SEO
- **Title Tags**: Create unique, descriptive titles under 60 characters. Place keywords at the beginning.
- **Meta Descriptions**: Write compelling summaries between 150-160 characters with a clear call to action (CTA).
- **Heading Structure**: Use a single `<h1>` per page. Follow a logical hierarchy (`<h2>`, `<h3>`).
- **Image Alt Text**: Add descriptive alt text for all images, incorporating keywords where appropriate.
- **URL Structure**: Use SEO-friendly URLs (short, descriptive, hyphen-separated).
- **Schema Markup**: Recommend or implement structured data (JSON-LD) for better rich snippet display.

### 3. Content Optimization
- **Readability**: Use short paragraphs, bullet points, and clear language.
- **Keyword Placement**: Ensure keywords appear in the first 100 words, headers, and conclusion.
- **Internal Linking**: Link to other relevant pages on the site to improve crawlability and authority.
- **External Linking**: Cite authoritative sources to build credibility.

### 4. Technical SEO Checklist
- **Mobile Friendliness**: Ensure the design is fully responsive and usable on small screens.
- **Page Load Speed**: Check for large images or inefficient scripts that could slow down the page.
- **SSL/HTTPS**: Confirm the site is served over a secure connection.
- **Robots.txt and Sitemap**: Verify these files exist and are correctly configured.

## Output format
When providing SEO optimizations, the agent should return:
1.  **Summary of Changes**: What was optimized and why.
2.  **Optimized Content**: The actual updated text/code.
3.  **SEO Report**: A brief overview of the keyword strategy, title, and meta descriptions used.

## Tools and Utilities
- Check `scripts/analyze_seo.py` for automated keyword density and readability checks.
## Resources
- Refer to `resources/seo_checklist.md` for a comprehensive pre-launch list.
- Check `examples/basic_optimization.md` for before/after examples.
- Use `resources/keyword_research_guide.md` to identify the best keywords for your content.
- See `scripts/analyze_seo.py` for automated keyword density and readability checks.
