import re
import sys
import json

def analyze_content(text, keywords):
    """Analyzes text for keyword density and simple readability."""
    words = re.findall(r'\w+', text.lower())
    total_words = len(words)
    
    keyword_counts = {}
    for kw in keywords:
        kw_lower = kw.lower()
        count = text.lower().count(kw_lower)
        keyword_counts[kw] = {
            "count": count,
            "density": (count / total_words) * 100 if total_words > 0 else 0
        }
        
    # Use a simpler and safer approach to counting sentences to avoid ReDoS
    # Splits by any character in .!? and filters out empty strings
    sentences = [s.strip() for s in text.replace('!', '.').replace('?', '.').split('.') if s.strip()]
    avg_sentence_length = total_words / len(sentences) if sentences else 0
    
    # Very simple readability heuristic (average sentence length)
    readability_score = "Good"
    if avg_sentence_length > 20:
        readability_score = "Difficult (Consider shorter sentences)"
    elif avg_sentence_length < 10:
        readability_score = "Very Simple"
        
    return {
        "total_words": total_words,
        "keyword_analysis": keyword_counts,
        "readability": {
            "avg_sentence_length": avg_sentence_length,
            "score": readability_score
        }
    }

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python analyze_seo.py '<text>' '<keywords_comma_separated>'")
        sys.exit(1)
        
    content = sys.argv[1]
    keywords = [k.strip() for k in sys.argv[2].split(",")]
    
    result = analyze_content(content, keywords)
    print(json.dumps(result, indent=4))
