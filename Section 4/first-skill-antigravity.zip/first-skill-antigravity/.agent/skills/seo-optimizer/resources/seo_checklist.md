# Comprehensive SEO Pre-Launch Checklist

Use this checklist to ensure your content is fully optimized before hit "Publish."

## 1. On-Page SEO
- [ ] **Title Tag**: Does it contain the primary keyword near the beginning? (Keep under 60 chars)
- [ ] **Meta Description**: Is it compelling and under 160 characters? Does it have a clear CTA?
- [ ] **H1 Tag**: Is there only one H1? Does it clearly state the page's topic?
- [ ] **Heading Structure**: Are subheaders (H2, H3, H4) used logically for structure?
- [ ] **URL Slug**: Is the URL short, descriptive, and hyphenated?
- [ ] **Image Alt Text**: Do all images have descriptive, keyword-rich alt text?

## 2. Content Quality
- [ ] **Keyword Density**: Is the primary keyword used naturally (1-2%)?
- [ ] **First 100 Words**: Does the primary keyword appear in the introduction?
- [ ] **Readability**: Are paragraphs short? Did you use bullet points or lists for scanners?
- [ ] **Internal Links**: Are there links to at least 2 other relevant pages on your site?
- [ ] **External Links**: Are there links to at least 1-2 high-authority external sites?
- [ ] **Search Intent**: Does the content actually answer the user's search query?

## 3. Technical SEO
- [ ] **Mobile Responsive**: Have you checked how the page looks on a smartphone?
- [ ] **Page Speed**: Are images compressed? (Use WebP where possible)
- [ ] **HTTPS**: Is the page served over a secure connection?
- [ ] **Canonical Tag**: Is there a canonical tag pointing to the source URL?
- [ ] **Schema Markup**: Is JSON-LD structured data implemented for products/reviews?

## 4. Final Review
- [ ] **Grammar and Spelling**: Have you run a spellcheck?
- [ ] **Call to Action (CTA)**: Is it clear what you want the user to do next?
- [ ] **Indexability**: Is the page set to "index" (no `noindex` tag)?
