# Keyword Research Guide

This resource provides a step-by-step approach to identifying the best keywords for your content and aligning them with user intent.

## 1. Identify Seed Keywords
Start with broad terms related to your topic. Think about what your audience would type into a search engine.

- **Focus**: What is the core problem or topic?
- **Variation**: Brainstorm synonyms and related phrases.

## 2. Analyze Search Intent
Keywords are useless if they don't match why the user is searching. Categorize keywords into:

1.  **Informational**: "How to bake a cake" (The user wants to learn).
2.  **Navigational**: "Gmail login" (The user wants to find a specific page).
3.  **Commercial Investigation**: "Best laptops 2024" (The user is comparing options before buying).
4.  **Transactional**: "Buy iPhone 15 Pro Max" (The user is ready to buy).

## 3. Use LSI (Latent Semantic Indexing) Keywords
These are terms related to your primary keyword. They help search engines understand the context of your page.

- **Example**: If your primary keyword is "Cold Brew," LSI terms might include "steeping time," "coarse grind," or "fridge temperature."

## 4. Evaluate Keyword Difficulty & Volume
Balance high-traffic keywords (harder to rank) with long-tail keywords (lower traffic but easier to rank and often more targeted).

- **Tools to use**: Google Keyword Planner, Ahrefs, SEMrush, or free alternatives like Ubersuggest.

## 5. Map Keywords to Content
Assign 1 primary keyword and 2-4 secondary keywords to each page. Avoid "Keyword Cannibalization" (having multiple pages targeting the exact same keyword).
