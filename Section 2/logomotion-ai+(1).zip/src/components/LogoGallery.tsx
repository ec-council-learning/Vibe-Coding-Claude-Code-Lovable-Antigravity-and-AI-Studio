import { useState, useEffect } from "react";
import { collection, query, orderBy, onSnapshot, limit } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../lib/firebase";
import { GeneratedLogo } from "../lib/gemini";
import { motion, AnimatePresence } from "motion/react";
import { Clock, Search, Download } from "lucide-react";
import { downloadSvgFile } from "../lib/svg";

interface SavedLogo extends GeneratedLogo {
  id: string;
  createdAt: any;
}

export default function LogoGallery() {
  const [logos, setLogos] = useState<SavedLogo[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const q = query(
      collection(db, "logos"), 
      orderBy("createdAt", "desc"),
      limit(24)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as SavedLogo[];
      setLogos(docs);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "logos");
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const filteredLogos = logos.filter(logo => 
    logo.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    logo.slogan.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex justify-center p-12">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-2 border-black border-t-transparent rounded-full"
        />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h2 className="text-3xl font-display font-bold">Community Showcase</h2>
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input 
            type="text"
            placeholder="Search logos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-white border border-gray-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-black/5 focus:border-black transition-all"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        <AnimatePresence>
          {filteredLogos.map((logo, idx) => (
            <motion.div
              key={logo.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.05 }}
              className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm hover:shadow-md transition-shadow group cursor-default relative"
            >
              <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                <button 
                  onClick={() => downloadSvgFile(logo)}
                  className="p-2 bg-white rounded-full shadow-md text-gray-600 hover:text-black hover:scale-105 transition-all text-black"
                  title="Download SVG"
                >
                  <Download size={16} />
                </button>
              </div>
              <div className="aspect-square bg-gray-50 rounded-xl mb-4 flex items-center justify-center p-8 overflow-hidden">
                <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-sm group-hover:scale-110 transition-transform duration-500">
                  {logo.parts.sort((a, b) => a.order - b.order).map((part) => (
                    <path
                      key={part.id}
                      d={part.path}
                      fill={part.fill ? part.color : "transparent"}
                      stroke={part.color}
                      strokeWidth={part.strokeWidth}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  ))}
                </svg>
              </div>
              <div className="space-y-1">
                <h3 className="font-display font-bold text-lg truncate" style={{ color: logo.primaryColor }}>
                  {logo.companyName}
                </h3>
                <p className="text-sm text-gray-500 truncate italic">"{logo.slogan}"</p>
                <div className="flex items-center gap-1.5 pt-2 text-[10px] text-gray-400 uppercase tracking-tighter">
                  <Clock size={10} />
                  <span>{logo.createdAt?.toDate ? new Date(logo.createdAt.toDate()).toLocaleDateString() : 'Just now'}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {filteredLogos.length === 0 && (
        <div className="text-center py-24 text-gray-400 font-sans">
          No logos found matching your search.
        </div>
      )}
    </div>
  );
}
