import { motion } from "motion/react";
import { GeneratedLogo } from "../lib/gemini";
import { RefreshCw, Play } from "lucide-react";
import { useState, useEffect } from "react";

interface AnimatedLogoProps {
  logo: GeneratedLogo;
}

export default function AnimatedLogo({ logo }: AnimatedLogoProps) {
  const [animationKey, setAnimationKey] = useState(0);

  const replay = () => setAnimationKey((prev) => prev + 1);

  return (
    <div className="flex flex-col items-center gap-8 w-full max-w-2xl mx-auto p-4 md:p-8">
      <div className="relative group perspective-1000 w-full aspect-square max-w-[400px] flex items-center justify-center bg-white rounded-3xl shadow-xl border border-gray-100 p-12 overflow-hidden">
        {/* Background decorative elements */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none">
          <div className="absolute top-0 left-0 w-full h-full" style={{ backgroundImage: `radial-gradient(circle at 2px 2px, ${logo.primaryColor} 1px, transparent 0)`, backgroundSize: '24px 24px' }}></div>
        </div>

        <motion.svg
          key={animationKey}
          viewBox="0 0 100 100"
          className="w-full h-full drop-shadow-2xl"
          initial="hidden"
          animate="visible"
        >
          {logo.parts.sort((a, b) => a.order - b.order).map((part, index) => (
            <motion.path
              key={part.id}
              d={part.path}
              fill={part.fill ? part.color : "transparent"}
              stroke={part.color}
              strokeWidth={part.strokeWidth}
              strokeLinecap="round"
              strokeLinejoin="round"
              variants={{
                hidden: { pathLength: 0, opacity: 0, scale: 0.8 },
                visible: {
                  pathLength: 1,
                  opacity: 1,
                  scale: 1,
                  transition: {
                    pathLength: { delay: index * 0.4, duration: 1.5, ease: "easeInOut" },
                    opacity: { delay: index * 0.4, duration: 0.5 },
                    scale: { delay: index * 0.4, duration: 0.8, type: "spring" },
                    fill: { delay: (index * 0.4) + 1, duration: 0.8 }
                  }
                }
              }}
              initial={part.fill ? { fillOpacity: 0 } : undefined}
              animate={part.fill ? { fillOpacity: 1 } : undefined}
            />
          ))}
        </motion.svg>
        
        <div className="absolute bottom-4 right-4 flex gap-2">
           <button 
            onClick={replay}
            className="p-2 bg-gray-50 hover:bg-gray-100 text-gray-500 rounded-full transition-colors shadow-sm"
            title="Replay Animation"
          >
            <RefreshCw size={18} />
          </button>
        </div>
      </div>

      <motion.div 
        key={`text-${animationKey}`}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.5 }}
        className="text-center space-y-3"
      >
        <h2 className="text-4xl md:text-5xl font-display font-bold tracking-tight" style={{ color: logo.primaryColor }}>
          {logo.companyName}
        </h2>
        <p className="text-xl font-sans text-gray-500 italic max-w-lg mx-auto leading-relaxed">
          "{logo.slogan}"
        </p>
        
        <div className="pt-6 border-t border-gray-100 mt-6 max-w-md mx-auto">
          <p className="text-sm font-sans text-gray-400 uppercase tracking-widest mb-2 font-semibold">The Concept</p>
          <p className="text-gray-600 font-sans leading-relaxed text-sm">
            {logo.concept}
          </p>
        </div>
      </motion.div>
    </div>
  );
}
