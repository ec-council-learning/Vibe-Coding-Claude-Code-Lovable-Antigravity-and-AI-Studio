import { FormEvent, useState } from "react";
import { Sparkles, ArrowRight } from "lucide-react";
import { motion } from "motion/react";

interface LogoFormProps {
  onSubmit: (description: string) => void;
  isLoading: boolean;
}

export default function LogoForm({ onSubmit, isLoading }: LogoFormProps) {
  const [description, setDescription] = useState("");

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (description.trim()) {
      onSubmit(description);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-xl mx-auto"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="relative group">
          <label 
            htmlFor="description" 
            className="block text-xs uppercase tracking-[0.2em] font-display font-semibold text-gray-400 mb-3 ml-1"
          >
            Your Vision
          </label>
          <textarea
            id="description"
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="e.g., A minimalist tech company called 'Nova' that focuses on space exploration. Use sharp geometric shapes and deep blue colors."
            className="w-full bg-white border border-gray-200 rounded-2xl p-6 text-lg font-sans focus:outline-none focus:ring-2 focus:ring-black/5 focus:border-black transition-all resize-none shadow-sm group-hover:shadow-md"
            required
            disabled={isLoading}
          />
        </div>
        
        <button
          type="submit"
          disabled={isLoading || !description.trim()}
          className="w-full relative overflow-hidden group py-4 px-8 bg-black text-white rounded-2xl font-display font-bold text-lg flex items-center justify-center gap-3 transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <div className="flex items-center gap-3">
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              >
                <Sparkles size={20} className="text-secondary" />
              </motion.div>
              <span>Designing your identity...</span>
            </div>
          ) : (
            <>
              <span>Design My Logo</span>
              <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </>
          )}
          
          <div className="absolute inset-0 bg-white/10 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 skew-x-[-20deg]" />
        </button>
      </form>
    </motion.div>
  );
}
