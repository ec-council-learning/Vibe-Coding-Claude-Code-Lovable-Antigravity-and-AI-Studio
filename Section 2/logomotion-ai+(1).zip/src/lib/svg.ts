import { GeneratedLogo } from "./gemini";

export const generateSvgString = (logo: GeneratedLogo): string => {
  const svgPaths = [...logo.parts].sort((a, b) => a.order - b.order).map(part => (
    `<path d="${part.path}" fill="${part.fill ? part.color : 'transparent'}" stroke="${part.color}" stroke-width="${part.strokeWidth}" stroke-linecap="round" stroke-linejoin="round" />`
  )).join('');
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">${svgPaths}</svg>`;
};

export const generateSvgDataUrl = (logo: GeneratedLogo): string => {
  const svgString = generateSvgString(logo);
  return `data:image/svg+xml;base64,${btoa(svgString)}`;
};

export const downloadSvgFile = (logo: GeneratedLogo) => {
  const svgString = generateSvgString(logo);
  const blob = new Blob([svgString], { type: 'image/svg+xml' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${logo.companyName.toLowerCase().replace(/\s+/g, '-')}-logo.svg`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};
