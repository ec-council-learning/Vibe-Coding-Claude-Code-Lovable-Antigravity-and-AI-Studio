export interface LogoPart {
  id: string;
  path: string;
  color: string;
  strokeWidth: number;
  fill: boolean;
  order: number;
}

export interface GeneratedLogo {
  companyName: string;
  slogan: string;
  primaryColor: string;
  secondaryColor: string;
  parts: LogoPart[];
  concept: string;
}

export async function generateLogo(description: string): Promise<GeneratedLogo> {
  const response = await fetch("/api/generate-logo", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ description }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || "Failed to generate logo");
  }

  return await response.json() as GeneratedLogo;
}
