import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, BrainCircuit, Play, History, Download, LogIn, LogOut, User as UserIcon, LayoutGrid } from "lucide-react";
import LogoForm from "./components/LogoForm";
import AnimatedLogo from "./components/AnimatedLogo";
import LogoGallery from "./components/LogoGallery";
import { generateLogo, GeneratedLogo } from "./lib/gemini";
import { auth, signIn, db, handleFirestoreError, OperationType } from "./lib/firebase";
import { onAuthStateChanged, signOut, User } from "firebase/auth";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { downloadSvgFile, generateSvgDataUrl } from "./lib/svg";

export default function App() {
  const [logo, setLogo] = useState<GeneratedLogo | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [showGallery, setShowGallery] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [lastPrompt, setLastPrompt] = useState("");

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
    });
    return () => unsubscribe();
  }, []);

  const handleGenerate = async (description: string) => {
    setLoading(true);
    setError(null);
    setSaveStatus('idle');
    setLastPrompt(description);
    try {
      const result = await generateLogo(description);
      setLogo(result);
      
      // Auto-save if user is logged in
      if (auth.currentUser) {
        await saveLogoToFirestore(result, description);
      }
    } catch (err) {
      console.error(err);
      setError("Failed to generate logo. Please try a different description or try again later.");
    } finally {
      setLoading(false);
    }
  };

  const saveLogoToFirestore = async (logoData: GeneratedLogo, prompt: string) => {
    if (!auth.currentUser) return;
    setIsSaving(true);
    setSaveStatus('saving');
    try {
      await addDoc(collection(db, "logos"), {
        ...logoData,
        description: prompt,
        svgDataUrl: generateSvgDataUrl(logoData),
        userId: auth.currentUser.uid,
        createdAt: serverTimestamp(),
      });
      setSaveStatus('saved');
    } catch (err) {
      console.error("Save failed:", err);
      setSaveStatus('error');
      // Still show the error context but don't break the UI
      try {
        handleFirestoreError(err, OperationType.CREATE, "logos");
      } catch (logErr) {
        // Error logged to console by handleFirestoreError
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleManualSave = async () => {
    if (!logo || !lastPrompt) return;
    
    if (!user) {
      try {
        const u = await signIn();
        if (u) {
          await saveLogoToFirestore(logo, lastPrompt);
        }
      } catch (err) {
        console.error("Sign in failed:", err);
      }
    } else if (saveStatus !== 'saved') {
      await saveLogoToFirestore(logo, lastPrompt);
    }
  };

  const reset = () => {
    setLogo(null);
    setError(null);
    setShowGallery(false);
  };

  const downloadSvg = () => {
    if (!logo) return;
    downloadSvgFile(logo);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col selection:bg-black selection:text-white">
      {/* Structural Grid Background */}
      <div className="fixed inset-0 opacity-[0.015] pointer-events-none z-0">
        <div className="absolute inset-0" style={{ backgroundImage: `linear-gradient(#000 1px, transparent 1px), linear-gradient(90deg, #000 1px, transparent 1px)`, backgroundSize: '40px 40px' }}></div>
      </div>

      <nav className="relative z-20 py-6 px-6 max-w-7xl mx-auto w-full flex justify-between items-center">
        <div className="flex items-center gap-2 cursor-pointer" onClick={reset}>
           <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center shadow-lg">
            <BrainCircuit className="text-secondary" size={18} />
          </div>
          <span className="font-display font-black tracking-tighter text-xl">LM.AI</span>
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={() => setShowGallery(!showGallery)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full font-display font-bold text-sm transition-all ${showGallery ? 'bg-black text-white' : 'bg-white border border-gray-100 text-gray-600 hover:bg-gray-50'}`}
          >
            <LayoutGrid size={16} />
            {showGallery ? 'Generator' : 'Gallery'}
          </button>

          {user ? (
            <div className="flex items-center gap-4 pl-4 border-l border-gray-200">
              <div className="hidden md:block text-right">
                <p className="text-xs font-bold text-gray-900">{user.displayName || 'Creator'}</p>
                <p className="text-[10px] text-gray-400 font-sans">{user.email}</p>
              </div>
              <button 
                onClick={() => signOut(auth)}
                className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                title="Sign Out"
              >
                <LogOut size={18} />
              </button>
            </div>
          ) : (
            <button 
              onClick={signIn}
              className="flex items-center gap-2 px-4 py-2 bg-black text-white rounded-full font-display font-bold text-sm hover:scale-105 transition-all shadow-md shadow-black/10"
            >
              <LogIn size={16} />
              Sign In
            </button>
          )}
        </div>
      </nav>

      <header className="relative z-10 pt-12 pb-8 px-6">
        <div className="max-w-7xl mx-auto flex flex-col items-center text-center">
          <h1 className="text-5xl md:text-7xl font-display font-black tracking-tighter mb-4 text-black uppercase">
            Logo<span className="text-gray-300">Motion</span><span className="text-secondary">.AI</span>
          </h1>
          <p className="text-lg font-sans text-gray-400 max-w-xl mx-auto leading-relaxed">
            Professional identities, generated and animated in seconds.
          </p>
        </div>
      </header>

      <main className="relative z-10 flex-1 px-6 pb-24">
        <div className="max-w-7xl mx-auto">
          {showGallery ? (
            <LogoGallery />
          ) : (
            <>
              {!logo ? (
                <div className="flex flex-col items-center">
                  <LogoForm onSubmit={handleGenerate} isLoading={loading} />
                  
                  {!user && !loading && (
                    <motion.p 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="mt-6 text-sm text-gray-400 font-sans italic"
                    >
                      Sign in to automatically save and showcase your creations.
                    </motion.p>
                  )}

                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5 }}
                    className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-4xl"
                  >
                    {[
                      { icon: <Sparkles className="text-secondary" />, title: "AI Precision", desc: "Complex semantic understanding of your brand values." },
                      { icon: <Play className="text-secondary" />, title: "Native Motion", desc: "Each logo is engineered for fluid web transitions." },
                      { icon: <History className="text-secondary" />, title: "Rapid Iteration", desc: "Design, animate, and refine identities instantly." }
                    ].map((feature, i) => (
                      <div key={i} className="bg-white/50 backdrop-blur-sm p-6 rounded-2xl border border-gray-100 text-center">
                        <div className="flex justify-center mb-4">{feature.icon}</div>
                        <h3 className="font-display font-bold text-gray-900 mb-2">{feature.title}</h3>
                        <p className="text-sm font-sans text-gray-500 leading-relaxed">{feature.desc}</p>
                      </div>
                    ))}
                  </motion.div>
                </div>
              ) : (
                <div className="flex flex-col items-center">
                  <AnimatePresence mode="wait">
                    <AnimatedLogo logo={logo} />
                  </AnimatePresence>
                  
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 2 }}
                    className="mt-12 flex flex-col items-center gap-6"
                  >
                    <div className="flex gap-4">
                      <button 
                        onClick={reset}
                        className="px-8 py-3 bg-white border border-gray-200 rounded-full font-display font-bold text-gray-600 hover:bg-gray-50 transition-colors shadow-sm"
                      >
                        Create Another
                      </button>
                      <button 
                        id="download-btn"
                        onClick={downloadSvg}
                        className="px-8 py-3 bg-[#f22f05] text-white border border-white rounded-full font-display font-bold flex items-center gap-2 shadow-xl shadow-black/10 transition-transform active:scale-95"
                      >
                        <Download size={18} />
                        Export SVG
                      </button>
                    </div>

                    {saveStatus === 'saved' ? (
                      <p className="text-xs font-sans text-green-500 flex items-center gap-2 font-bold">
                        <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
                        Saved to Community Showcase
                      </p>
                    ) : (
                      <button 
                        onClick={handleManualSave}
                        disabled={saveStatus === 'saving'}
                        className="text-xs font-sans text-gray-500 hover:text-black flex items-center gap-2 transition-colors border-b border-gray-200 pb-0.5"
                      >
                        <div className={`w-1.5 h-1.5 rounded-full ${saveStatus === 'saving' ? 'bg-amber-400 animate-pulse' : 'bg-gray-300'}`} />
                        {saveStatus === 'saving' ? 'Saving...' : user ? 'Click to Save to Gallery' : 'Sign In to Save to Gallery'}
                        {saveStatus === 'error' && <span className="text-red-500">(Retry)</span>}
                      </button>
                    )}
                  </motion.div>
                </div>
              )}
            </>
          )}

          {error && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mt-8 p-4 bg-red-50 border border-red-100 text-red-600 rounded-xl text-center font-sans"
            >
              {error}
            </motion.div>
          )}
        </div>
      </main>

      <footer className="relative z-10 py-8 border-t border-gray-100 text-center">
        <p className="text-xs font-sans text-gray-400 uppercase tracking-widest font-semibold flex items-center justify-center gap-2">
          Powered by Gemini Vision Engines <span className="w-1 h-1 bg-secondary rounded-full"></span> 2026 LogoMotion Labs
        </p>
      </footer>
    </div>
  );
}


