import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import cors from "cors";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

  // API routes FIRST
  app.post("/api/generate-logo", async (req, res) => {
    try {
      const { description } = req.body;
      if (!description) {
        return res.status(400).json({ error: "Description is required" });
      }

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Generate a professional logo design for a company with this description: "${description}". 
        The response must be a valid JSON object representing the logo structure.
        The logo should be abstract, modern, and suitable for SVG animation.
        Break the logo symbol into 2-5 distinct parts/paths that can be animated separately.
        Use a 100x100 viewBox coordinate system for the SVG paths.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            required: ["companyName", "slogan", "primaryColor", "secondaryColor", "parts", "concept"],
            properties: {
              companyName: { type: Type.STRING },
              slogan: { type: Type.STRING },
              primaryColor: { type: Type.STRING, description: "HEX color code" },
              secondaryColor: { type: Type.STRING, description: "HEX color code" },
              concept: { type: Type.STRING, description: "Short explanation of the logo concept" },
              parts: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  required: ["id", "path", "color", "strokeWidth", "fill", "order"],
                  properties: {
                    id: { type: Type.STRING },
                    path: { type: Type.STRING, description: "SVG path d attribute data" },
                    color: { type: Type.STRING, description: "HEX color code" },
                    strokeWidth: { type: Type.NUMBER },
                    fill: { type: Type.BOOLEAN },
                    order: { type: Type.NUMBER, description: "Animation sequence order" },
                  }
                }
              }
            }
          }
        }
      });

      if (!response.text) {
        throw new Error("No response from AI");
      }

      res.json(JSON.parse(response.text.trim()));
    } catch (error) {
      console.error("Error generating logo:", error);
      res.status(500).json({ error: "Failed to generate logo" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
